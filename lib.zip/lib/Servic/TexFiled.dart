



 import 'package:flutter/material.dart';
import 'package:get/get.dart';

class TextFieldController extends GetxController{

   TextEditingController email = TextEditingController();
   TextEditingController password = TextEditingController();
   TextEditingController newEmail = TextEditingController();
   TextEditingController name = TextEditingController();
   TextEditingController age = TextEditingController();

 }