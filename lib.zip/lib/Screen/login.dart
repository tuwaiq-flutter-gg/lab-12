





import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lab11/Servic/AnoMOStlly.dart';
import 'package:lab11/Servic/TexFiled.dart';
import 'package:lab11/Servic/data.dart';
import 'package:lab11/componet/Button.dart';
import 'package:lab11/componet/TixstFiled.dart';

class Login extends StatelessWidget {
   const Login({super.key});

   @override
   Widget build(BuildContext context) {

     TextFieldController controller = Get.put(TextFieldController());
     DataBaseController datacontroller = Get.put(DataBaseController());

     return SafeArea(
       child: Scaffold(
         body: ListView(
           children: [

             Padding(
               padding: const EdgeInsets.all(20.0),
               child: Column(
                 children: [

                   const SizedBox(height: 10,),

                   const Center(child: Text('Email:'),),
                   Center(child:TixsetFiled(controller: controller.email, decoration:InputDecoration(
                            border:InputBorder.none,
                           hintText:"Enter Email"




       ), ),),

                   const SizedBox(height: 10,),

                   const Center(child: Text('password :'),),
                   Center(child: TixsetFiled(controller: controller.password, decoration:InputDecoration(
                            border:InputBorder.none,
                           hintText:"Enter password"




       ),
       ),),

                   const SizedBox(height: 10,),

                

                   const SizedBox(height: 10,),

                   Center(child:ElevatedButton(onPressed: () {
                   createAccount(email: controller.email.text, 
                   password: controller.password.text);
                 }, child:Text("logIN")),),


                 ],
               ),
             )

           ],
         ),
       ),
     );
   }
 }